#include <bits/stdc++.h>
typedef long long int ll;
#define ld long double

using namespace std;
 
void set_s(vector<vector<ll> > &adj, ll k, vector<vector<ll> > &v,vector<ll> &level){
    for(int i=0;i<adj[k].size();i++){
        if(level[adj[k][i]]==-1){
            level[adj[k][i]] = level[k]+1;
            v[0][adj[k][i]] = k;
            set_s(adj,adj[k][i],v,level);
        }
    }
}
 
ll dfs(vector<ll> &v, vector<ll> &ans, ll k, vector<ll> &level, vector<vector<ll> > &adj){
    ans[k] = v[k];
    for(int i=0;i<adj[k].size();i++){
        if(level[adj[k][i]] > level[k]){
            ans[k]+=dfs(v,ans,adj[k][i],level,adj);
        }
    }
    return ans[k];
 
}
 
void solve(){
    ll n,m,a,b;
    cin>>n>>m;
    vector<vector<ll> > adj(n),v(log2(n)+1,vector<ll> (n,-1));
    vector<ll> level(n,-1),f(n),ans(n),te(n-1);
    for(int i=0;i<n-1;i++) cin>>te[i];
    for(int i=0;i<n-1;i++){
        cin>>a;
        adj[a-1].push_back(te[i]-1);
        adj[te[i]-1].push_back(a-1);
    }
    level[0]=0;
    set_s(adj,0,v,level);
    for(int i=1;i<v.size();i++){
        for(int j=0;j<n;j++) v[i][j] = (v[i-1][j] == -1) ? v[i-1][j] : v[i-1][v[i-1][j]];
    }
    for(int i=0;i<m;i++){
        cin>>a>>b;
        a--;
        b--;
        ll c=a,d=b;
        if(level[a]>level[b]){
            ll t = level[a]-level[b];
            while(t){
                ll temp = log2(t);
                a = v[temp][a];
                t-=1<<temp;
            }
        }else{
            ll t = -level[a]+level[b];
            while(t){
                ll temp = log2(t);
                b = v[temp][b];
                t-=1<<temp;
            }
        }
        while(a!=b){
            if(v[0][a] == v[0][b]){
                a = v[0][a];
                b = v[0][b];
                break;
            }
            for(int i=1;i<v.size();i++){
                if(v[i][a] == v[i][b]){
                    a = v[i-1][a];
                    b = v[i-1][b];
                    break;
                }
            }
        }
        f[c]++;
        f[d]++;
        f[a]--;
        if(v[0][a]!=-1) f[v[0][a]]--;
    }
    dfs(f,ans,0,level,adj);
    for(int i=0;i<n;i++) cout<<ans[i]<<" ";
    cout<<endl;  
 
}
 
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
    ll t = 1;
    while(t--) solve();
}