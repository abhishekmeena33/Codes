#include <bits/stdc++.h>
typedef long long int ll;
#define ld long double

using namespace std;

void solve(){
    ll n,m,a,b;
    cin>>n>>m;
    vector<vector<ll> > adj(n);
    for(int i=0;i<m;i++){
        cin>>a>>b;
        adj[a-1].push_back(b-1);
        adj[b-1].push_back(a-1);
    }
    vector<ll> v(n,0);
    for(int i=0;i<n;i++){
        if(v[i]==0){
            v[i]=1;
            queue<ll> q;
            q.push(i);
            while(!q.empty()){
                ll x = q.front();
                q.pop();
                for(int j=0;j<adj[x].size();j++){
                    if(v[adj[x][j]]==0){
                        v[adj[x][j]]=3-v[x];
                        q.push(adj[x][j]);
                    }else if(v[adj[x][j]]==v[x]){
                        cout<<"NO"<<endl;
                        return;
                    }
                }
            }
        }
    }
    cout<<"YES"<<endl;
    for(int i=0;i<n;i++) cout<<v[i]<<" ";
    cout<<endl;

}   
 
int main(){
    ll t = 1;
    while(t--) solve();
}