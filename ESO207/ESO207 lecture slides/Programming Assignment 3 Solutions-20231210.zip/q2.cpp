#include <bits/stdc++.h>
typedef long long int ll;
#define ld long double

using namespace std;

ll time_s = 0;

void dfs(ll x, vector<vector<ll> > &adj, vector<ll> &degree, vector<ll> &disc, vector<ll> &low, vector<ll> &visited,ll parent){
    visited[x]=true;
    disc[x] = low[x] = ++time_s;
    for(int i=0;i<adj[x].size();i++){
        ll y =adj[x][i];
        if(!visited[y]){
            dfs(y,adj,degree,disc,low,visited,x);
            low[x] = min(low[x],low[y]);
            if(low[y] > disc[x]){
                degree[x]--;
                degree[y]--;
            }
        }else if(y!=parent) low[x] = min(low[x],disc[y]);
    }
}

void solve(){
    ll n,m,a;
    cin>>n>>m;
    vector<vector<ll> > adj(n);
    vector<ll> v(m),degree(n,0),disc(n,0),low(n,0),visited(n,0);
    for(int i=0;i<m;i++) cin>>v[i];
    for(int i=0;i<m;i++){
        cin>>a;
        adj[v[i]-1].push_back(a-1);
        adj[a-1].push_back(v[i]-1);
        degree[v[i]-1]++;
        degree[a-1]++;
    }
    v = vector<ll> (n,0);
    for(int i=0;i<n;i++){
        if(!visited[i]) dfs(i,adj,degree,disc,low,visited,-1);
    }
    for(int i=0;i<n;i++){
        if(degree[i]) cout<<"1 ";
        else cout<<"0 ";
    }
}   
 
int main(){
    ll t = 1;
    while(t--) solve();
}